@extends('layout.site')
@section('titulo', 'Página não encontrada')


@section('conteudo')
<div class="content">
    <div class="item-title">
        <h1 class="fas fa-exclamation-triangle"></h1>
        <h1>404</h1>
        <p>Página não encontrada.</p>
    </div>
</div>

@endsection