@include('layout._includes.header')

@yield('banner')

<div class="container">
@yield('conteudo')
</div>

<footer>
@include('layout._includes.footer')
