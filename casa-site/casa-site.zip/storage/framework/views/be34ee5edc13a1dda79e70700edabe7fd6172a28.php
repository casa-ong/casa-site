<?php $__env->startSection('titulo', 'Lista de notícias'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="content">
        <div class="item-title">
            <h1 class="">Lista de notícias</h1>
            <a class="btn" href="<?php echo e(route('admin.noticia.adicionar')); ?>">Adicionar</a>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="table">
            <table>
                <thead>
                    <tr class="table-header">
                        <th>Id</th>
                        <th>Título</th>
                        <th>Publicado</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody class="table-body">
                    <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($registro->id); ?></td>
                            <td><?php echo e($registro->titulo); ?></td>
                            <td><?php echo e($registro->publicado ? "Sim" : "Não"); ?></td>
                            <td class="action-cell">
                                <a class="btn" href="<?php echo e(route('admin.noticia.editar',$registro->id)); ?>" title="Editar">
                                    <span class="fas fa-pencil-alt"></span>
                                </a>
                                <a class="btn btn-danger" href="<?php echo e(route('admin.noticia.deletar',$registro->id)); ?>" onclick="return confirm('Tem certeza que deseja deletar o projeto?');" title="Deletar">
                                    <span class="fas fa-trash-alt"></span>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/admin/noticias/index.blade.php ENDPATH**/ ?>