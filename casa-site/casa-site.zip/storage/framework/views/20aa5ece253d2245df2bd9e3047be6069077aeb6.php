<?php $__env->startSection('titulo', $noticia->titulo.' - CASA'); ?>

<?php $__env->startSection('conteudo'); ?>
    <div class="content">
        <div id="noticias" class="title">
            <h1><?php echo e($noticia->titulo); ?></h1>
            <p><?php echo e(date('d/m/Y', strtotime($noticia->created_at))); ?> por <a href="#"><?php echo e($noticia->autor); ?></a></p>
            <p style="align-self: flex-start"><?php echo e($noticia->manchete); ?></p>
        </div>
        <div class="img">
            <img src="<?php echo e(asset($noticia->anexo)); ?>" alt="">
        </div>
        <div class="text">
            <?php echo $noticia->toArray()['texto']; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/site/noticias/noticia.blade.php ENDPATH**/ ?>