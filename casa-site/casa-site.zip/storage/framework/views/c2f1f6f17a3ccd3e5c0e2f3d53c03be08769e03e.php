<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>" style="display: inline-block;">
            <?php if(trim($slot) === 'Laravel'): ?>
                <img src="https://laravel.com/img/notification-logo.png" class="logo" alt="Laravel Logo">
            <?php else: ?>
                <img src="<?php echo e(isset($banner) ? asset($banner) : asset('img/banner/casa-banner.png')); ?>" style="max-width: 400px; width: 100%;" alt="Centro de Apoio Social e Ambiental: Plantando o amanhã">
            <?php endif; ?>
        </a>
    </td>
</tr>
<?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>