<?php if($errors->any()): ?>
    <p class="error">Campos com * são obrigatórios!</p>
<?php endif; ?>
<?php ($user = Auth::user()); ?>
<input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">

<div class="input-field">
    <label for="titulo">Título*</label>
    <input class="<?php echo e($errors->has('titulo') ? 'error' : ''); ?>" type="text" name="titulo" value="<?php echo e(isset($registro->titulo) ? $registro->titulo : old('titulo')); ?>" placeholder="Digite aqui o título da notícia">
    <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="input-field">
    <label for="texto">Manchete*</label>
    <textarea class="<?php echo e($errors->has('manchete') ? 'error' : old('manchete')); ?>" name="manchete" type="text" placeholder="Digite aqui a manchete da notícia, ela aparecerá nos cards das notícias"><?php echo e(isset($registro->manchete) ? $registro->manchete : old('manchete')); ?></textarea>
    <?php $__errorArgs = ['manchete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="input-field">
    <label for="texto">Texto*</label>
    <textarea class="<?php echo e($errors->has('texto') ? 'error' : old('texto')); ?>" id="summernote" name="texto" type="text" placeholder="Digite aqui o texto da notícia"><?php echo e(isset($registro->texto) ? $registro->texto : old('texto')); ?></textarea>
    <?php $__errorArgs = ['texto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="input-field">
    <label for="nome">Banner da notícia</label>
    <input type="file" class="<?php echo e($errors->has('anexo') ? 'error' : ''); ?>" name="anexo" onchange="document.getElementById('img-banner').src = window.URL.createObjectURL(this.files[0])">
    <?php $__errorArgs = ['anexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="input-field">
    <img id="img-anexo" src="<?php echo e(isset($registro->anexo) ? asset($registro->anexo) : ''); ?>" alt="">
</div>    

<label class="input-checkbox" for="publicado">Publicar agora?
    <input type="checkbox" name="publicado" <?php echo e(isset($registro->publicado) && $registro->publicado == true ? 'checked' : ''); ?> value="true">
    <span class="checkmark"></span>
</label><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/admin/noticias/_form.blade.php ENDPATH**/ ?>