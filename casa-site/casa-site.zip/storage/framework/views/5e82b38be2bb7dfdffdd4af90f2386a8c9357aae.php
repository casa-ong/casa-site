<?php $__env->startSection('titulo', 'Página não encontrada'); ?>


<?php $__env->startSection('conteudo'); ?>
<div class="content">
    <div class="item-title">
        <h1 class="fas fa-exclamation-triangle"></h1>
        <h1>404</h1>
        <p>Página não encontrada.</p>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/errors/404.blade.php ENDPATH**/ ?>