<?php $__env->startSection('titulo', 'Adicionar sugestão'); ?>
<?php $__env->startSection('anchor', 'sugestoes'); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="content">
    <div class="item-title">
        <h1>Envie uma sugestão</h1>

        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e(Session::get('success')); ?></p>
            </div>
        <?php endif; ?>
        
    </div>
    <div class="item-form">
        <form action="<?php echo e(route('sugestao.salvar')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo $__env->make('admin.sugestao._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="input-btn">
                <button class="btn">Salvar</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/adicionarSugestao.blade.php ENDPATH**/ ?>