[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>