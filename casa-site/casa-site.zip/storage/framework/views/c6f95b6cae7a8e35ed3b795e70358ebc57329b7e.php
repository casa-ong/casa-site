<?php if($errors->any()): ?>
    <p class="error">Campos com * são obrigatórios!</p>
<?php endif; ?>
<input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">
<h3>Informações do site</h3>
<div class="input-field">
    <label for="titulo_site">Titulo do site</label>
    <input class="<?php echo e($errors->has('titulo_site') ? 'error' : ''); ?>" type="text" name="titulo_site" value="<?php echo e(isset($registro->titulo_site) ? $registro->titulo_site : old('titulo_site')); ?>" placeholder="Digite aqui o titulo do site">
    <?php $__errorArgs = ['titulo_site'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="slogan">Slogan</label>
    <input class="<?php echo e($errors->has('slogan') ? 'error' : ''); ?>" type="text" name="slogan" value="<?php echo e(isset($registro->slogan) ? $registro->slogan : old('slogan')); ?>" placeholder="Digite aqui o slogan do site">
    <?php $__errorArgs = ['slogan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="input-field">
    <label for="logo">Ícone do site</label>
    <div class="input-field row">
        <input class="<?php echo e($errors->has('logo') ? 'error' : ''); ?>" type="file" name="logo" onchange="document.getElementById('img-logo').src = window.URL.createObjectURL(this.files[0])">
        <img id="img-logo" src="<?php echo e(isset($registro->logo) ? asset($registro->logo) : ''); ?>" alt="" style="border: 1px solid rgba(0, 0, 0, 0.2); border-radius: 5px;">
    </div>    
    <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="input-field">
    <label for="banner">Banner do site</label>
    <input class="<?php echo e($errors->has('banner') ? 'error' : ''); ?>" type="file" name="banner" onchange="document.getElementById('img-banner').src = window.URL.createObjectURL(this.files[0])">
    <?php $__errorArgs = ['banner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="input-field">
    <img id="img-banner" src="<?php echo e(isset($registro->banner) ? asset($registro->banner) : ''); ?>" alt="">
</div>    

<h3>Informações da organização</h3>
<div class="input-field">
    <label for="texto_sobre">Nossa missão</label>
    <textarea type="text" name="texto_sobre" placeholder="Escreve aqui um texto sobre a organização"><?php echo e(isset($registro->texto_sobre) ? $registro->texto_sobre : old('texto_sobre')); ?></textarea>
    <?php $__errorArgs = ['texto_sobre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="email">Email da organização</label>
    <input class="<?php echo e($errors->has('email') ? 'error' : ''); ?>" type="text" name="email" value="<?php echo e(isset($registro->email) ? $registro->email : old('email')); ?>" placeholder="Digite aqui o email da organização">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="telefone">Telefone para contato da organização</label>
    <input class="<?php echo e($errors->has('telefone') ? 'error' : ''); ?> telefone" type="text" name="telefone" value="<?php echo e(isset($registro->telefone) ? $registro->telefone : old('telefone')); ?>" placeholder="Digite aqui o telefone da organização">
    <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<h3>Redes sociais</h3>
<div class="input-field">
    <label for="instagram">Instagram</label>
    <input type="url" name="instagram" value="<?php echo e(isset($registro->instagram) ? $registro->instagram : old('instagram')); ?>" placeholder="Digite aqui o instagram da organização">
    <?php $__errorArgs = ['instagran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="twitter">Twitter</label>
    <input type="url" name="twitter" value="<?php echo e(isset($registro->twitter) ? $registro->twitter : old('twitter')); ?>" placeholder="Digite aqui o twitter da organização">
    <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="facebook">Facebook</label>
    <input type="url" name="facebook" value="<?php echo e(isset($registro->facebook) ? $registro->facebook : old('facebook')); ?>" placeholder="Digite aqui o facebook da organização">
    <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/admin/sobre/_form.blade.php ENDPATH**/ ?>