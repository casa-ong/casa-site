<div class="item-title">
    <h1>Sobre nós</h1>
</div>
<div class="item">
    <div class="content">
        <?php echo isset($sobre->texto_sobre) ? $sobre->toArray()['texto_sobre'] : ''; ?>

    </div>
</div>
<?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/sobre.blade.php ENDPATH**/ ?>