<?php $__env->startSection('titulo', 'Notícias - CASA'); ?>
<?php $__env->startSection('anchor', 'noticias'); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="item-title">
    <h1>Notícias</h1>
</div>
<div class="item border-0">
    <?php if(isset($noticias) && count($noticias) > 0): ?>
        <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('site.noticias._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>Ops, ainda não temos nenhuma novidade...</p>
    <?php endif; ?>
</div>
<div class="content-footer">
    <div class="page-nav">
        <?php echo e($noticias->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/site/noticias/noticias.blade.php ENDPATH**/ ?>