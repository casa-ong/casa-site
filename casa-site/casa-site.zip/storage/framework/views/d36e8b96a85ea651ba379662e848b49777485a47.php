<div class="user-card">
    <div class="card-img">
        <img src="<?php echo e(asset($registro->foto)); ?>" alt="">
    </div>
    <div class="card-data">
        <h4><?php echo e($registro->name); ?></h4>
        <p>
            <?php echo e($registro->getAge()); ?> anos - 
            <a href="<?php echo e(route('site.projeto', $registro->projeto->id ?? '')); ?>">
                <?php echo e($registro->projeto->nome ?? ''); ?> 
            </a>
        </p>
        <p><?php echo e($registro->cidade); ?> - <?php echo e($registro->estado); ?></p>
    </div>
</div><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/site/voluntarios/_card.blade.php ENDPATH**/ ?>