<?php echo e($slot); ?>

<?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>