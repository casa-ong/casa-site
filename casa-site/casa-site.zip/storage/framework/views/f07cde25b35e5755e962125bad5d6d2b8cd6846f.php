<?php $__env->startSection('titulo', 'Projetos - CASA'); ?>
<?php $__env->startSection('anchor', 'projetos'); ?>

<?php $__env->startSection('conteudo'); ?>

<div class="item-title">
    <h1>Nossos projetos</h1>
</div>
<div class="item border-0">
    <?php if(isset($projetos) && count($projetos) > 0): ?>
        <?php $__currentLoopData = $projetos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projeto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('site.projetos._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>Poxa, nossos projetos ainda não foram cadastrados...</p>
    <?php endif; ?>
</div>
<div class="content-footer">
    <div class="page-nav">
        <?php echo e($projetos->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/site/projetos/projetos.blade.php ENDPATH**/ ?>