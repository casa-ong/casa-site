<?php echo $__env->make('layout._includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('banner'); ?>

<div class="container">
<?php echo $__env->yieldContent('conteudo'); ?>
</div>

<footer>
<?php echo $__env->make('layout._includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/layout/site.blade.php ENDPATH**/ ?>