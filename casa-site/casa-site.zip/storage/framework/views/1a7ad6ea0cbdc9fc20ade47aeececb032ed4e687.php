<div class="card">
    <div class="card-img">
        <a href="<?php echo e(route('site.noticia', $noticia->id)); ?>"><img src="<?php echo e(asset($noticia->anexo)); ?>" alt=""></a>
    </div>
    <div class="card-text">                            
        <h4>
            <a title="<?php echo e($noticia->titulo); ?>"  href="<?php echo e(route('site.noticia', $noticia->id)); ?>"><?php echo e($noticia->titulo); ?></a>
        </h4>
    </div>
    <div class="action text-center">
        <a href="<?php echo e(route('site.noticia', $noticia->id)); ?>" class="btn btn-green">Leia mais</a>
    </div>
</div><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/site/noticias/_card.blade.php ENDPATH**/ ?>