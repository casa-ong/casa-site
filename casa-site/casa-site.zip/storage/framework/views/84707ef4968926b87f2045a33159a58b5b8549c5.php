<?php $__env->startComponent('mail::message'); ?>

<h1><?php echo e($detalhes['titulo'] ?? ''); ?></h1>

<br>

<?php echo e($detalhes['texto'] ?? ''); ?>  

<br>

<?php echo e($detalhes['info'] ?? ''); ?>

  

<?php $__env->startComponent('mail::button', ['url' => $detalhes['url']]); ?>

Ver mais detalhes

<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

   

Com carinho,<br>

<?php echo e(config('app.name')); ?>


<p style="font-size: 12px;">Se deseja deixar de receber e-mails <a href="<?php echo e(route('newsletter.editar', [$detalhes['newsletter_id'], $detalhes['newsletter_token']])); ?>">descadastre-se</a></p>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/emails/unsubscribe.blade.php ENDPATH**/ ?>