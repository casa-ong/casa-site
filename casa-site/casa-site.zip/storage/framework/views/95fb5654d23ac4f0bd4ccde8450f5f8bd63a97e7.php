<?php if($errors->any()): ?>
    <p class="error">Campos com * são obrigatórios!</p>
<?php endif; ?>
<input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">
<div class="input-field">
    <label for="nome">Nome*</label>
    <input class="<?php echo e($errors->has('nome') ? 'error' : ''); ?>" type="text" name="nome" value="<?php echo e(isset($registro->nome) ? $registro->nome : old('nome')); ?>" placeholder="Digite aqui o nome do evento">
    <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="nome">Descrição*</label>
    <textarea id="summernote" class="<?php echo e($errors->has('descricao') ? 'error' : ''); ?>" type="text" name="descricao" placeholder="Descreva aqui como será o evento"><?php echo e(isset($registro->descricao) ? $registro->descricao : old('descricao')); ?></textarea>
    <?php $__errorArgs = ['descricao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="nome">Banner do evento</label>
    <input type="file" class="<?php echo e($errors->has('anexo') ? 'error' : ''); ?>" name="anexo" onchange="document.getElementById('img-banner').src = window.URL.createObjectURL(this.files[0])">
    <?php $__errorArgs = ['anexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="input-field">
    <img id="img-banner" src="<?php echo e(isset($registro->anexo) ? asset($registro->anexo) : ''); ?>" alt="">
</div>    

<div class="input-field">
    <label for="nome">Data</label>
    <div class="input-field datetime">
        <input type="date" name="data" value="<?php echo e(isset($registro->data) ? $registro->data : ''); ?>" placeholder="Digite a data do evento">
        <input type="time" name="hora" value="<?php echo e(isset($registro->hora) ? date('H:i', strtotime($registro->hora)) : ''); ?>" placeholder="Digite a hora do evento">
    </div>
</div>

<label class="input-checkbox" for="publicado">Publicar agora?
    <input type="checkbox" name="publicado" <?php echo e(isset($registro->publicado) && $registro->publicado == true ? 'checked' : ''); ?> value="true">
    <span class="checkmark"></span>
</label>

<?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/admin/eventos/_form.blade.php ENDPATH**/ ?>