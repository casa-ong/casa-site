<?php $__env->startSection('titulo', 'Painel de controle - CASA'); ?>
<?php $__env->startSection('anchor', 'controle'); ?>
<?php ($user = Auth::user()); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="content">
        <div class="item-title">
		    <h1 class="">Bem-vindo ao seu painel de controle, <?php echo e($user['name']); ?>!</h1>
        </div>
        <div class="item" style="border-bottom: 0;">
            <a class="admin-card" href="<?php echo e(route('admin.noticias')); ?>">
                <span class="fas fa-newspaper"></span>
                <h2>Notícias</h2>
            </a>
            <a class="admin-card" href="<?php echo e(route('admin.eventos')); ?>">
                <span class="fas fa-calendar-alt"></span>
                <h2>Eventos</h2>
            </a>
            <a class="admin-card" href="<?php echo e(route('admin.projetos')); ?>">
                <span class="fas fa-scroll"></span>
                <h2>Projetos</h2>
            </a>
            <a class="admin-card" href="<?php echo e(route('admin.voluntarios')); ?>">
                <span class="fas fa-users"></span>
                <h2>Voluntários</h2>
            </a>
            <a class="admin-card" href="<?php echo e(route('admin.sugestoes')); ?>">
                <span class="fas fa-comments"></span>
                <h2>Sugestões</h2>
            </a>
            <a class="admin-card" href="<?php echo e(route('admin.newsletters')); ?>">
                <span class="fas fa-envelope-open-text"></span>
                <h2>NewsLetters</h2>
            </a>
            <a class="admin-card" href="<?php echo e(route('admin.sobre')); ?>">
                <span class="fas fa-cog"></span>
                <h2>Configurações</h2>
            </a>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/admin/index.blade.php ENDPATH**/ ?>