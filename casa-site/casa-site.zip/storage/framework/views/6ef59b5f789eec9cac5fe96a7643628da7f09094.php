<?php if($errors->any()): ?>
    <p class="error">Campos com * são obrigatórios!</p>
<?php endif; ?>

<input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">
<input type="checkbox" name="lida" value="true" style="display: none;">

<div class="input-field">
    <label for="assunto">Assunto*</label>
    <input <?php echo e(isset($registro->assunto) ? 'readonly' : ''); ?> class="<?php echo e($errors->has('assunto') ? 'error' : ''); ?>" type="text" name="assunto" value="<?php echo e(isset($registro->assunto) ? $registro->assunto : old('assunto')); ?>" placeholder="Digite aqui o assunto da sugestão">
    <?php $__errorArgs = ['assunto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="mensagem">Mensagem*</label>
    <textarea <?php echo e(isset($registro->mensagem) ? 'readonly' : ''); ?> class="<?php echo e($errors->has('mensagem') ? 'error' : ''); ?>" type="text" name="mensagem" placeholder="Descreva aqui sua sugestão"><?php echo e(isset($registro->mensagem) ? $registro->mensagem : old('mensagem')); ?></textarea>
    <?php $__errorArgs = ['mensagem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="email">Email*</label>
    <input <?php echo e(isset($registro->email) ? 'readonly' : ''); ?> class="<?php echo e($errors->has('email') ? 'error' : ''); ?>" type="text" name="email" value="<?php echo e(isset($registro->email) ? $registro->email : old('email')); ?>" placeholder="Digite aqui o seu email">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="telefone">Celular/whatsapp*</label>
    <input <?php echo e(isset($registro->telefone) ? 'readonly' : ''); ?> class="<?php echo e($errors->has('telefone') ? 'error' : ''); ?> telefone" type="text" name="telefone" value="<?php echo e(isset($registro->telefone) ? $registro->telefone : old('telefone')); ?>" placeholder="Digite aqui o seu número do celular">
    <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/admin/sugestao/_form.blade.php ENDPATH**/ ?>