
        <div class="item-black">
            <form id="form-btn"  action="<?php echo e(route('newsletter.salvar')); ?>#newsletter" method="POST" enctype="multipart/form-data">
        
                <?php if(Session::has('newsletter')): ?>
                    <div class="alert alert-success text-center">
                        <p><?php echo e(Session::get('newsletter')); ?></p>
                    </div>
                <?php endif; ?>
                
                <div class="input-field">
                    <?php echo e(csrf_field()); ?>

                        <label id="newsletter" for="item-title">Receba novidades</label>
                        <input name="email_newsletter" class="<?php echo e($errors->has('email_newsletter') ? 'error' : ''); ?>" type="text" placeholder="Digite seu email para se cadastrar">
                        <?php $__errorArgs = ['email_newsletter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error error-dark"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="input-btn m-0">
                        <button form="form-btn" type="submit" class="btn btn-dark">Enviar</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="item">
            <div class="social-icons">

                <?php ($sobre = App\Sobre::latest('updated_at')->first()); ?>
                <?php if(isset($sobre->twitter)): ?>
                    <a class="social-icon" href="<?php echo e(isset($sobre->twitter) ? $sobre->twitter : '#'); ?>" target="_blank">
                        <i class="fab fa-twitter"></i>
                    </a>
                <?php endif; ?>

                <?php if(isset($sobre->instagram)): ?>
                    <a class="social-icon" href="<?php echo e(isset($sobre->instagram) ? $sobre->instagram : '#'); ?>" target="_blank">
                        <i class="fab fa-instagram"></i>
                    </a>
                <?php endif; ?>

                <?php if(isset($sobre->facebook)): ?>
                    <a class="social-icon" href="<?php echo e(isset($sobre->facebook) ? $sobre->facebook : '#'); ?>" target="_blank">
                        <i class="fab fa-facebook"></i>
                    </a>
                <?php endif; ?>
                
            </div>
            <p>© 2020 Todos os direitos reservados.</p>
        </div>

        <script src="<?php echo e(asset('js/summernote_config.js')); ?>"></script>
        <?php echo $__env->yieldContent('scripts'); ?>
    </footer>
</body>
</html><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/layout/_includes/footer.blade.php ENDPATH**/ ?>