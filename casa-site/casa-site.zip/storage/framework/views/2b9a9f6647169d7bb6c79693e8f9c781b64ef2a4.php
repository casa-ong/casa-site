<div class="gallery-cell carousel-item" style="background: linear-gradient( rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6) ), url('<?php echo e(asset($item->anexo)); ?>'); background-size: 100%;">
    <div class="carousel-title">                            
        <h1><a href="<?php echo e(route('site.noticia', $item->id)); ?>"><?php echo e($item->titulo); ?></a></h1>
    </div>
</div><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/site/_includes/_carousel_item.blade.php ENDPATH**/ ?>