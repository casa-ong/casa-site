<?php $__env->startSection('titulo', 'Projetos - CASA'); ?>

<?php $__env->startSection('conteudo'); ?>
<div id="titulo" class="item-title">
    <h1>Nossos voluntários</h1>
</div>
<p class="breadcrumbs"><a href="<?php echo e(route('site.home')); ?>">Início</a> / <a href="<?php echo e(route('site.voluntarios')); ?>">Voluntários</a> / <?php echo e($estado); ?></p>
<div class="row">
    <?php if(isset($registros) && count($registros) > 0): ?>
        <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('site.voluntarios._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>Nenhum voluntário aqui por enquanto, <strong>seja o primeiro!</strong></p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <style>
        div.user-card {
            display: flex;
            flex-direction: row
        }

        div.user-card div.card-data
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/site/voluntarios/regiao.blade.php ENDPATH**/ ?>