<?php $__env->startSection('titulo', 'Lista de Eventos'); ?>
<?php $__env->startSection('anchor', 'eventos'); ?>

<?php $__env->startSection('conteudo'); ?>
        <div class="item-title">
            <h1>Eventos</h1>
        </div>
        <div class="item border-0">
        <?php if(isset($eventos) && count($eventos) > 0): ?>
            <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('site.eventos._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>Eita, ainda não houve nenhum evento, digite seu email abaixo para saber das novidades</p>
        <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/site/eventos/eventos.blade.php ENDPATH**/ ?>