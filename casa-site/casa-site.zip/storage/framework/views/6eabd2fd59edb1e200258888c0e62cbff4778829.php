<?php $__env->startSection('titulo', 'Inicio - CASA'); ?>

<?php $__env->startSection('banner'); ?>
        <div class="banner" style="background-image: url(<?php echo e(isset($sobre->banner) ? asset($sobre->banner) : ''); ?>);"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <?php if(isset($noticias) && count($noticias) > 0): ?>
        <div class="gallery js-flickity carousel"
            data-flickity-options='{ "wrapAround": true, "autoPlay": true }'>
            <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('site._includes._carousel_item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <div class="alert alert-error text-center">
            <p><?php echo e(Session::get('error')); ?></p>
        </div>
    <?php endif; ?>
    
    <a id="sobre"></a>
    <div class="item-title">
        <h1>Quem somos</h1>
    </div>
    <div class="item border-0">
        <div class="card card-big">
            <div class="card-img">
                <img src="<?php echo e(asset('img/icons/volunteers.png')); ?>" alt="Desenho de voluntários">
            </div>
            <div class="card-text">                            
                <h4>Uma equipe de <br><strong><?php echo e($n_voluntarios); ?> voluntários</strong></h4>
                <p>Temos voluntários espalhados por <strong>todo Brasil!</strong></p>
            </div>
            <div class="action text-center">
                <a href="" class="btn btn-green">Conheça</a>
            </div>
        </div>
        <div class="card card-big">
            <div class="card-img">
                <img src="<?php echo e(asset('img/icons/project.png')); ?>" alt="Desenho de voluntários">
            </div>
            <div class="card-text">                            
                <h4>Envolvidos em <br><strong><?php echo e($n_projetos); ?> projetos</strong></h4>
                <p>Projetos para melhoria do <strong>meio ambiente</strong> e da <strong>sociedade</strong>.</p>
            </div>
            <div class="action text-center">
                <a href="" class="btn btn-green">Conheça</a>
            </div>
        </div>
    </div>

    <?php if(isset($sobre)): ?>
        <div class="item-title">
            <h1>Nossa <strong>missão</strong></h1>
        </div>
        <div class="item sobre text-center">
            <?php echo e($sobre->texto_sobre ?? ''); ?>

        </div>
    <?php endif; ?>

    <?php if(isset($projetos) && count($projetos) > 0): ?>
        <div id="projetos" class="item-title mt-1">
            <h1>Nossos <strong>projetos</strong></h1>
        </div>
        <div class="item">
            <?php $__currentLoopData = $projetos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projeto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('site.projetos._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <a id="contribua"></a>
    <div class="item-title mt-1">
        <h1>Contribua</h1>
    </div>
    <div class="item">
        <div class="card card-small">
            <div class="card-img">
                <img src="<?php echo e(asset('img/icons/volunteer.png')); ?>" alt="Desenho de mãos com um coração">
            </div>
            <div class="card-text">                            
                <h4>Sendo <br><strong>voluntário</strong></h4>
            </div>
            <div class="action text-center">
                <a href="<?php echo e(route('site.voluntario.adicionar')); ?>" class="btn btn-green">Saiba como</a>
            </div>
        </div>
        <div class="card card-small">
            <div class="card-img">
                <img src="<?php echo e(asset('img/icons/suggest.png')); ?>" alt="Desenho de mulher opinando">
            </div>
            <div class="card-text">                            
                <h4>Fazendo <br><strong>sugestões</strong></h4>
            </div>
            <div class="action text-center">
                <a href="<?php echo e(route('sugestao.adicionar')); ?>" class="btn btn-green">Saiba como</a>
            </div>
        </div>
        <div class="card card-small">
            <div class="card-img">
                <img src="<?php echo e(asset('img/icons/donate.png')); ?>" alt="Desenho de mão segurando moeda">
            </div>
            <div class="card-text">                            
                <h4>Fazendo uma <br><strong>doação</strong></h4>
            </div>
            <div class="action text-center">
                <a onclick="window.alert('Aff, essa função ainda está em construção, entre em contato para doar pfv!')" class="btn btn-green">Saiba como</a>
            </div>
        </div>        
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/home.blade.php ENDPATH**/ ?>