<?php if($errors->any()): ?>
    <p class="error">Confire novamente os campos em vermelho</p>
<?php endif; ?>
<div class="input-field">
    <label for="name">Nome*</label>
    <input class="<?php echo e($errors->has('name') ? 'error' : ''); ?>" type="text" name="name" value="<?php echo e(isset($registro->name) ? $registro->name : old('name')); ?>" placeholder="Digite aqui seu nome">

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>

    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="cpf">CPF*</label>
    <input <?php echo e(isset($registro->cpf) ? "readonly" : ""); ?> class="<?php echo e($errors->has('cpf') ? 'error' : ''); ?> cpf " type="text" name="cpf" value="<?php echo e(isset($registro->cpf) ? $registro->cpf : old('cpf')); ?>" placeholder="Digite aqui seu cpf">
    <?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="nascimento">Data de nascimento</label>
    <input class="<?php echo e($errors->has('nascimento') ? 'error' : ''); ?>" type="date" name="nascimento" value="<?php echo e(isset($registro->cpf) ? $registro->nascimento : old('nascimento')); ?>" placeholder="Digite aqui sua data de nascimento">
    <?php $__errorArgs = ['nascimento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="profissao">Profissão*</label>
    <input class="<?php echo e($errors->has('profissao') ? 'error' : ''); ?>" type="text" name="profissao" value="<?php echo e(isset($registro->profissao) ? $registro->profissao : old('profissao')); ?>" placeholder="Digite aqui sua profissão">
    <?php $__errorArgs = ['profissao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>       
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="estado">Estado*</label>
    <select class="<?php echo e($errors->has('estado') ? 'error' : ''); ?>" name="estado" id="estados">
        <option selected value><?php echo e(__('Selecione um estado')); ?></option>
        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if( isset($registro->estado) && $estado[0] == $registro->estado): ?>
                <option selected value="<?php echo e($estado[0]); ?>"><?php echo e($estado[1]); ?></option>
            <?php endif; ?>
            <option value="<?php echo e($estado[0]); ?>"><?php echo e($estado[1]); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>    
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="cidade">Cidade</label>
    <input class="<?php echo e($errors->has('cidade') ? 'error' : ''); ?>" type="text" name="cidade" value="<?php echo e(isset($registro->cidade) ? $registro->cidade : old('cidade')); ?>" placeholder="Digite aqui o nome da sua cidade">
    <?php $__errorArgs = ['cidade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>       
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="descricao">Descrição*</label>
    <textarea class="<?php echo e($errors->has('descricao') ? 'error' : ''); ?>" type="text" name="descricao" placeholder="Descreva você mesmo"><?php echo e(isset($registro->descricao) ? $registro->descricao : old('descricao')); ?></textarea>
    <?php $__errorArgs = ['descricao'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="projeto_id">Projeto</label>
    <select class="<?php echo e($errors->has('projeto_id') ? 'error' : ''); ?>" name="projeto_id">
        <option hidden disabled selected value><?php echo e(__('Selecione um projeto')); ?></option>
        <option value><?php echo e(__('Nenhum')); ?></option>
        <?php $__currentLoopData = $projetos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projeto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($registro->projeto_id) && $projeto->id == $registro->projeto_id): ?>
                <option selected value="<?php echo e($projeto->id); ?>"><?php echo e($projeto->nome); ?></option>
            <?php endif; ?>
            <option value="<?php echo e($projeto->id); ?>"><?php echo e($projeto->nome); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['projeto_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>    
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="input-field">
    <label for="foto">Foto do voluntario (quadrada, 1x1)</label>
    <div class="input-field row">
        <input class="<?php echo e($errors->has('foto') ? 'error' : ''); ?>" type="file" name="foto" onchange="document.getElementById('img-foto').src = window.URL.createObjectURL(this.files[0])">
        <img id="img-foto" src="<?php echo e(isset($registro->foto) ? asset($registro->foto) : asset('/img/voluntarios/user_profile.png')); ?>" alt="" style="border: 1px solid rgba(0, 0, 0, 0.2); border-radius: 5px;">
    </div>    
    <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="input-field">
    <label for="email">Email*</label>
    <input <?php echo e(isset($registro->email) ? "readonly" : ""); ?> class="<?php echo e($errors->has('email') ? 'error' : ''); ?>" type="text" name="email" value="<?php echo e(isset($registro->email) ? $registro->email : old('email')); ?>" placeholder="Digite aqui seu email">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>
<div class="input-field">
    <label for="telefone">Telefone/Celular*</label>
    <input class="<?php echo e($errors->has('telefone') ? 'error' : ''); ?> telefone" type="text" name="telefone" value="<?php echo e(isset($registro->telefone) ? $registro->telefone : old('telefone')); ?>" placeholder="Digite aqui seu telefone">
    <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/admin/voluntarios/_form.blade.php ENDPATH**/ ?>