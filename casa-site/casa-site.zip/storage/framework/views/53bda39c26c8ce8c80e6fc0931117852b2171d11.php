<div class="card">
    <div class="card-img">
        <a href="<?php echo e(route('site.evento', $evento->id)); ?>"><img src="<?php echo e($evento->anexo); ?>" alt=""></a>
    </div>
    <div class="card-text">                            
        <p><a href="#"><?php echo e($evento->user->name); ?></a></p>
        <h4><a href="<?php echo e(route('site.evento', $evento->id)); ?>"><?php echo e($evento->nome); ?></a></h4>
        <p>Data: <?php echo e(date('d/m/Y', strtotime($evento->data))); ?></p>
        <!--p>{-- $evento->descricao --}</p-->
    </div>
</div><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/site/eventos/_card.blade.php ENDPATH**/ ?>