<?php $__env->startSection('titulo', 'Dados do voluntário - '.config('APP_NAME', 'CASA')); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="content">
    <div class="item-title">
        <?php if((Auth::user()->id ?? null) == $registro->id): ?>
            <h1>Minha conta</h1>
        <?php else: ?>
            <h1>Dados do voluntário</h1>
        <?php endif; ?>
    </div>
    <div class="w-text mx-auto border-1">
        <div class="row align-center">
            <img class="user-profile mt-1" src="<?php echo e(asset($registro->foto ?? '/img/voluntarios/user_profile.png')); ?>" alt="">
        </div>
        <div class="item py-0 border-0">
            <p>
                <strong><?php echo e($registro->name); ?></strong> tem 
                <strong><?php echo e($registro->getAge()); ?> anos</strong>
                e mora <?php echo isset($registro->cidade) ? 'em <strong>'.$registro->cidade.'</strong>' : ''; ?>

                <?php echo 'no estado de <strong>'.$registro->estado.'</strong>'; ?>, trabalha como 
                <strong><?php echo e($registro->profissao); ?></strong> 
                <?php echo isset($registro->projeto->id) ? 'e participa do projeto <a href="'.route('site.projeto', $registro->projeto->id).'">'.$registro->projeto->nome.'</a>.' : ''; ?>

                <?php echo Auth::user() ? 'Seu e-mail para contato é <strong>'.$registro->email.'</strong> e o seu número de telefone é <strong>'.$registro->telefone.'</strong>.' : ''; ?>

                Na sua descrição <strong><?php echo e($registro->name); ?></strong> diz "<?php echo e($registro->descricao); ?>".
            </p>
        </div>
    </div>
    <div class="row mt-1 mx-auto">
        <form class="row" id="adminForm" action="<?php echo e(route('admin.voluntario.aprovar.admin')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="email" value="<?php echo e($registro->email ?? ''); ?>">

            <?php if(!Auth::guest() && (!$registro->admin || Auth::user()->id == $registro->id)): ?>
                <a class="btn m-0-2" href="<?php echo e(route('admin.voluntario.aprovar', $registro->id)); ?>" title="<?php echo $registro->aprovado ? 'Remove do menu de voluntários do site.' : 'Adiciona ao menu de voluntários do site.'; ?>">
                    <?php echo e($registro->aprovado ? 'Ocultar de voluntários' : 'Mostrar em voluntários'); ?>

                </a>
                <button form="adminForm" class="btn m-0-2" title="<?php echo $registro->admin ? 'Remove acesso à conta, porém permance sendo voluntário.' : 'Dá privelégios de administrador ao voluntário'; ?>" onclick="return confirm('<?php echo e($registro->id == (Auth::user()->id ?? '') ? 'Tem certeza que quer deixar de ser administrador e permanecer apenas como voluntário?' : 'Tem certeza que deseja tornar esse voluntário em administrador? (Esta ação só poderá ser desfeita por ele!)'); ?>');">
                    <span class="fas <?php echo e($registro->admin ? 'fa-lock' : 'fa-unlock'); ?>"></span> <?php echo e($registro->admin ? 'Excluir privilégios' : 'Tornar administrador'); ?>

                </button>
                <a class="btn m-0-2 btn-danger" href="<?php echo e(route('admin.voluntario.deletar',$registro->id)); ?>" onclick="return confirm('Excluir essa conta permanentemente?');" title="Exclui a conta permanentemente.">
                    <span class="fas fa-trash-alt"></span>
                </a>
            <?php endif; ?> 

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/admin/voluntarios/ver.blade.php ENDPATH**/ ?>