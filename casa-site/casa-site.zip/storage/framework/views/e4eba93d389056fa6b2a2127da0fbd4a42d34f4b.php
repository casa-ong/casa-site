<div class="card">
    <div class="card-img">
        <a href="<?php echo e(route('site.projeto', $projeto->id)); ?>"><img src="<?php echo e(asset($projeto->anexo)); ?>" alt=""></a>
    </div>
    <div class="card-text">                            
        <h4>
            <a title="<?php echo e($projeto->nome); ?>" href="<?php echo e(route('site.projeto', $projeto->id)); ?>"><?php echo e($projeto->nome); ?></a>
        </h4>
    </div>
    <div class="action text-center">
        <a href="<?php echo e(route('site.projeto', $projeto->id)); ?>" class="btn btn-green">Leia mais</a>
    </div>
</div><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/site/projetos/_card.blade.php ENDPATH**/ ?>