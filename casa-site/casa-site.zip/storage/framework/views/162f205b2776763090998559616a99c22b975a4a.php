<?php $__env->startSection('titulo', 'Lista de Voluntários'); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="content">
        <div class="item-title">
            <h1 class="">Lista de Voluntários</h1>
            <a class="btn" href="<?php echo e(route('admin.voluntario.adicionar')); ?>">Adicionar</a>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e(Session::get('success')); ?></p>
                </div>
            <?php elseif(Session::has('error')): ?>
                <div class="alert alert-error">
                    <p><?php echo e(Session::get('error')); ?></p>
                </div>
            <?php endif; ?>
        </div>
        <div class="table">
            <table>
                <thead>
                    <tr class="table-header">
                        <th>Nome</th>
                        <th>Email</th>
                        <th>CPF</th>
                        <th>Projeto</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody class="table-body">
                    <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($registro->name); ?></td>
                            <td><?php echo e($registro->email); ?></td>
                            <td><?php echo e($registro->cpf); ?></td>
                            <td><?php echo e(isset($registro->projeto_id) ? $registro->projeto->nome : "Nenhum"); ?></td>
                            <td class="action-cell">
                                <?php if(Auth::user()->id != $registro->id): ?>
                                    <a class="btn" href="<?php echo e(route('admin.voluntario.ver', $registro->id)); ?>" title="Ver">
                                        <span class="fas fa-eye"></span>
                                    </a>
                                <?php endif; ?>

                                <?php if(Auth::user()->id == $registro->id): ?>
                                    <a class="btn" href="<?php echo e(route('admin.voluntario.editar')); ?>" title="Editar">
                                        <span class="fas fa-pencil-alt"></span>
                                    </a>
                                <?php endif; ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/admin/voluntarios/index.blade.php ENDPATH**/ ?>