<?php $__env->startSection('titulo', 'Editar voluntário'); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="content">
    <div class="item-title">
        <h1>Minha conta</h1>
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <p><?php echo e(session('status')); ?></p>
            </div>
        <?php endif; ?>
    </div>
    <div class="row mt-1 mx-auto">
        
        <?php if(Auth::user()->id == $registro->id): ?>
            <?php if($registro->admin): ?>
                <a class="btn m-0-2" href="<?php echo e(route('admin.voluntario.aprovar', $registro->id)); ?>" title="<?php echo $registro->aprovado ? 'Remove do menu de voluntários do site.' : 'Adiciona ao menu de voluntários do site.'; ?>">
                    <?php echo e($registro->aprovado ? 'Ocultar de voluntários' : 'Mostrar em voluntários'); ?>

                </a>
                <form id="adminForm" action="<?php echo e(route('admin.voluntario.aprovar.admin')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="email" value="<?php echo e($registro->email ?? ''); ?>">
                    <button form="adminForm" class="btn m-0-2" title="<?php echo $registro->admin ? 'Remove acesso à conta, porém permance sendo voluntário.' : 'Dá privelégios de administrador ao voluntário'; ?>" onclick="return confirm('<?php echo e($registro->id == Auth::user()->id ? 'Tem certeza que quer deixar de ser administrador e permanecer apenas como voluntário?' : 'Tem certeza que deseja tornar esse voluntário em administrador? (Esta ação só poderá ser desfeita por ele!)'); ?>');">
                        <?php echo e($registro->admin ? 'Excluir privilégios' : 'Tornar administrador'); ?>

                    </button>
                </form>
            <?php endif; ?>
            <form id="alterarSenhaForm" action="<?php echo e(route('password.email')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="email" value="<?php echo e($registro->email ?? ''); ?>">
                <button form="alterarSenhaForm" class="btn m-0-2" onclick="return confirm('Você receberá um email com o link para resetar sua senha, certo?');">
                    Alterar senha
                </button>
            </form>
            <a class="btn m-0-2 btn-danger" href="<?php echo e(route('admin.voluntario.deletar',$registro->id)); ?>" onclick="return confirm('Excluir essa conta permanentemente?');" title="Exclui a conta permanentemente.">
                <span class="fas fa-trash-alt"></span>
            </a>
        <?php endif; ?> 

    </div>
    <div class="item-form">
        <form action="<?php echo e(route('admin.voluntario.atualizar', $registro->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="_method" value="put">
            <?php echo $__env->make('admin.voluntarios._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="input-btn">
                <button class="btn">Salvar</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/admin/voluntarios/editar.blade.php ENDPATH**/ ?>