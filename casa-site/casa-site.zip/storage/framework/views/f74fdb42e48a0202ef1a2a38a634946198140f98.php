<?php $__env->startSection('titulo', $projeto->nome.' - CASA'); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="post">
    <div class="content">
        <div class="img">
            <img src="<?php echo e(asset($projeto->anexo)); ?>" alt="">
        </div>
        <div class="text">
            <div id="noticias" class="title">
                <h1><?php echo e($projeto->nome); ?></h1>
            </div>
            <?php echo $projeto->toArray()['descricao']; ?>

            <p><?php echo e(strftime('%A, %d de %B  de %Y', strtotime($projeto->created_at))); ?></p>
        </div>
    </div>
    <section class="sidebar">
        <h1>Últimas <strong>notícias<strong></h1>
        <div class="row align-center">

            <?php if(isset($noticias) && count($noticias) > 0): ?>
            <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('site.noticias._card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>Ops, ainda não temos nenhuma novidade...</p>
            <?php endif; ?>

        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vinesnts/Documentos/2020.1/Programação WEB/casa-site/casa-site/resources/views/site/projetos/projeto.blade.php ENDPATH**/ ?>